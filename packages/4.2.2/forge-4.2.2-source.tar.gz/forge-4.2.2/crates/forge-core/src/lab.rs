use std::fs;
use std::path::Path;

use crate::error::{ForgeError, Result};
use crate::hostnet;
use crate::network::Mode;
use crate::ownership::{self, Ownership};
use crate::paths::ForgePaths;
use crate::profile::{Profile, SYSTEM_URI, WHONIX_GW_NAME, WHONIX_WS_NAME};
use crate::progress::{self, Progress};
use crate::pull;
use crate::role::{Role, VmPower};
use crate::usb::{self, Resolve, UsbId};
use crate::virt;
use crate::xml::{self, DomainSpec};

#[derive(Debug, Clone)]
pub struct Forge {
    pub paths: ForgePaths,
    pub uri: String,
}

#[derive(Debug, Clone)]
pub struct Created {
    pub name: String,
    pub uuid: String,
    pub xml: String,
}

#[derive(Debug)]
pub struct VmStatus {
    pub ownership: Ownership,
    pub power: VmPower,
    pub role_ok: Result<()>,
    /// USB dongle B currently in the domain XML, if any.
    pub dongle: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DongleLink {
    Connected(String),
    Already(String),
    Disconnected,
    Absent,
}

#[derive(Debug, Clone)]
pub struct InventoryRow {
    pub profile: Profile,
    pub image: &'static str,
    pub vms: Vec<String>,
}

impl Forge {
    pub fn open() -> Result<Self> {
        let paths = ForgePaths::discover();
        paths.ensure_user()?;
        let _ = crate::boxes::ensure_system_source();
        let uri = virt::uri()?;
        Ok(Self { paths, uri })
    }

    pub fn open_paths(paths: ForgePaths) -> Result<Self> {
        paths.ensure_user()?;
        Ok(Self {
            paths,
            uri: SYSTEM_URI.to_owned(),
        })
    }

    pub fn prepare_all(
        &self,
        sift_ova: Option<&Path>,
        progress: &Progress,
    ) -> Result<crate::prepare::PrepareReport> {
        if sift_ova.is_some_and(|path| !path.is_file()) {
            return Err(ForgeError::InvalidInput(
                "--sift-ova must be an existing local OVA file".to_owned(),
            ));
        }
        let run = || crate::prepare::run(self, sift_ova, progress);
        if self.paths.privileged_bases && !crate::cmd::has_priv_session() {
            let session = crate::cmd::SudoSession::start()?;
            crate::cmd::scope_priv(session, run)
        } else {
            run()
        }
    }

    /// Prepare only selected profiles, preserving the same verification and resume rules.
    pub fn prepare_selected(
        &self,
        profiles: &[Profile],
        sift_ova: Option<&Path>,
        progress: &Progress,
    ) -> Result<crate::prepare::PrepareReport> {
        let run = || crate::prepare::run_selected(self, profiles, sift_ova, progress);
        if self.paths.privileged_bases && !crate::cmd::has_priv_session() {
            let session = crate::cmd::SudoSession::start()?;
            crate::cmd::scope_priv(session, run)
        } else {
            run()
        }
    }

    /// Download and verify bases without installing hooks or defining guests.
    pub fn download_selected(
        &self,
        profiles: &[Profile],
        sift_ova: Option<&Path>,
        progress: &Progress,
    ) -> Result<crate::prepare::PrepareReport> {
        let run = || crate::prepare::download_selected(self, profiles, sift_ova, progress);
        if self.paths.privileged_bases && !crate::cmd::has_priv_session() {
            let session = crate::cmd::SudoSession::start()?;
            crate::cmd::scope_priv(session, run)
        } else {
            run()
        }
    }

    pub fn pull(&self, profile: Profile, progress: &Progress) -> Result<()> {
        pull::pull(&self.paths, profile, progress)?;
        Ok(())
    }

    pub fn create(
        &self,
        profile: Profile,
        name: Option<&str>,
        dry_run: bool,
        progress: &Progress,
    ) -> Result<Vec<Created>> {
        profile.require_engine()?;
        if !pull::base_ready(&self.paths, profile) {
            return Err(ForgeError::NotFound(format!(
                "no verified base for {} — run: forge pull {}",
                profile.id(),
                profile.id()
            )));
        }
        if !dry_run {
            crate::hook::ensure_installed(&self.paths)?;
            if Mode::load(&self.paths)? == Mode::Standard {
                self.prepare_standard_networks()?;
            }
        }
        if pull::needs_privileged_prepare(&self.paths) {
            progress::message(
                progress,
                format!(
                    "sudo: prepare {} (overlay dir + readable bases) — do not sudo forge",
                    self.paths.root.display()
                ),
            );
        }
        pull::ensure_lab_storage(&self.paths)?;
        pull::verify_base_digest(&self.paths, profile, progress)?;
        if profile == Profile::Whonix {
            if name.is_some() {
                return Err(ForgeError::InvalidInput(
                    "create whonix takes no extra name — it always creates whonix-gateway + whonix-workstation"
                        .to_owned(),
                ));
            }
            return self.create_whonix_pair(dry_run, progress);
        }
        let name = name
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| profile.default_name());
        Ok(vec![self.create_one(
            profile,
            name,
            profile.role(),
            &self.paths.base_qcow2(profile),
            None,
            dry_run,
            progress,
        )?])
    }

    fn create_whonix_pair(&self, dry_run: bool, progress: &Progress) -> Result<Vec<Created>> {
        let proof: crate::ownership::BaseProof =
            crate::ownership::read_json(&self.paths.proof_file(Profile::Whonix))?;
        let ws = proof.extra.first().ok_or_else(|| {
            ForgeError::Ownership("whonix proof has no workstation disk".to_owned())
        })?;
        let gw_digest = proof.base_digest.clone();
        let gw_path = proof.base_path.clone();
        let ws_path = ws.path.clone();
        let ws_digest = ws.digest.clone();
        if !dry_run {
            virt::ensure_whonix_net(&self.uri)?;
        }
        let gw = self.create_one(
            Profile::Whonix,
            WHONIX_GW_NAME,
            Role::WhonixGw,
            Path::new(&gw_path),
            Some((gw_digest.as_str(), Profile::Whonix.memory_mib())),
            dry_run,
            progress,
        )?;
        let ws_vm = self.create_one(
            Profile::Whonix,
            WHONIX_WS_NAME,
            Role::WhonixWs,
            Path::new(&ws_path),
            Some((ws_digest.as_str(), Profile::Whonix.workstation_memory_mib())),
            dry_run,
            progress,
        )?;
        Ok(vec![gw, ws_vm])
    }

    #[allow(clippy::too_many_arguments)]
    fn create_one(
        &self,
        profile: Profile,
        name: &str,
        role: Role,
        base: &Path,
        digest_mem: Option<(&str, u32)>,
        dry_run: bool,
        progress: &Progress,
    ) -> Result<Created> {
        validate_vm_name(name)?;
        let digest = if let Some((d, _)) = digest_mem {
            d.to_owned()
        } else {
            pull::verify_file_digest(
                base,
                &pull::expected_digest(&self.paths, profile)?,
                progress,
            )?
        };
        let memory = digest_mem
            .map(|(_, m)| m)
            .unwrap_or_else(|| profile.memory_mib());
        let overlay = self.paths.overlay_qcow2(name);
        let uuid = uuid::Uuid::new_v4().to_string();
        let spec = DomainSpec {
            name,
            uuid: &uuid,
            profile: profile.id(),
            role,
            overlay: &overlay.to_string_lossy(),
            base: &base.to_string_lossy(),
            base_digest: &digest,
            memory_mib: memory,
            vcpus: profile.vcpus(),
        };
        let xml = xml::domain_xml_with(
            &spec,
            crate::security::Policy::for_paths(&self.paths)?,
            Mode::load(&self.paths)?,
        );
        crate::network::check_domain(&xml, role, Mode::load(&self.paths)?)?;
        if dry_run {
            return Ok(Created {
                name: name.to_owned(),
                uuid,
                xml,
            });
        }
        if virt::domain_exists(&self.uri, name)? {
            return Err(ForgeError::AlreadyExists(format!(
                "libvirt domain {name} already exists"
            )));
        }
        if overlay.exists() {
            return Err(ForgeError::AlreadyExists(format!(
                "overlay {} already exists",
                overlay.display()
            )));
        }
        if self.paths.ownership_file(name).exists() {
            return Err(ForgeError::AlreadyExists(format!(
                "Forge already owns VM {name}"
            )));
        }
        let _ = virt::ensure_vms_pool(&self.uri, &self.paths.vms);
        pull::ensure_lab_storage(&self.paths)?;
        progress::message(progress, format!("Creating overlay {}", overlay.display()));
        virt::qemu_img_create_overlay(base, &overlay)?;
        let ownership = Ownership {
            name: name.to_owned(),
            uuid: uuid.clone(),
            profile: profile.id().to_owned(),
            role: role.id().to_owned(),
            overlay: overlay.display().to_string(),
            base: base.display().to_string(),
            base_digest: digest,
            libvirt_uri: self.uri.clone(),
        };
        ownership::write_json_atomic(&self.paths.ownership_file(name), &ownership)?;
        virt::define_xml(&self.uri, &xml)?;
        Ok(Created {
            name: name.to_owned(),
            uuid,
            xml,
        })
    }

    pub fn start(&self, name: &str, progress: &Progress) -> Result<()> {
        crate::hook::ensure_installed(&self.paths)?;
        let own = self.require_owned(name)?;
        pull::ensure_lab_storage(&self.paths)?;
        self.ensure_backing_seclabel(&own)?;
        // Digest runs in the qemu hook, immediately before QEMU. Hashing here
        // as well would read the base twice; Whonix bases are about 100 GiB.
        self.assert_backing(&own)?;
        self.assert_one_wan(&own)?;
        self.ensure_role_shape(&own)?;
        let xml = virt::dumpxml(&self.uri, name)?;
        crate::network::check_domain(&xml, own.role()?, Mode::load(&self.paths)?)?;
        self.assert_dongle_exclusive(Some(name))?;
        if name == WHONIX_WS_NAME {
            let gw = virt::domstate(&self.uri, WHONIX_GW_NAME).unwrap_or(VmPower::Shutoff);
            if !gw.is_active() {
                return Err(ForgeError::Role(
                    "start whonix-gateway before whonix-workstation".to_owned(),
                ));
            }
        }
        if Mode::load(&self.paths)? == Mode::Standard {
            self.prepare_standard_networks()?;
        } else if own.role()? == Role::WhonixGw {
            self.prepare_gateway_exit(progress)?;
        } else if own.role()? == Role::OsintClearnet {
            let report = hostnet::enforce()?;
            progress::message(progress, report.trim_end());
        }
        progress::message(
            progress,
            "qemu hook re-checks the base digest, role, and dongle B before QEMU starts",
        );
        virt::start(&self.uri, name)?;
        self.maybe_attach_dongle_b(name, own.role()?, progress)?;
        Ok(())
    }

    /// Live-attach dongle B after the qemu hook has returned. Retries while
    /// libvirt still holds the start job.
    pub(crate) fn attach_kali_live(&self, name: &str) -> Result<()> {
        let own = self.require_owned(name)?;
        if own.role()? != Role::OsintClearnet {
            return Ok(());
        }
        let mut last = None;
        for _ in 0..40 {
            match virt::domstate(&self.uri, name) {
                Ok(power) if power.is_active() => {
                    let _ = hostnet::enforce();
                    return self.maybe_attach_dongle_b(name, Role::OsintClearnet, &progress::noop);
                }
                Ok(_) => std::thread::sleep(std::time::Duration::from_millis(200)),
                Err(error) => {
                    last = Some(error);
                    std::thread::sleep(std::time::Duration::from_millis(200));
                }
            }
        }
        Err(last.unwrap_or_else(|| {
            ForgeError::Virt(format!(
                "{name} did not stay up long enough to attach dongle B"
            ))
        }))
    }

    pub fn stop(&self, name: &str, force: bool) -> Result<()> {
        let own = self.require_owned(name)?;
        if name == WHONIX_GW_NAME && !force {
            if let Ok(ws) = virt::domstate(&self.uri, WHONIX_WS_NAME) {
                if ws.is_active() {
                    return Err(ForgeError::Role(
                        "stop whonix-workstation before whonix-gateway (or use --force)".to_owned(),
                    ));
                }
            }
        }
        let _ = self.maybe_detach_dongle_b(name, own.role()?);
        if Mode::load(&self.paths)? == Mode::Standard {
            // Standard mode never reconfigures host network interfaces.
        } else if own.role()? == Role::WhonixGw {
            let _ = hostnet::release_usb();
            let _ = hostnet::enforce();
        } else if own.role()? == Role::OsintClearnet {
            let _ = hostnet::enforce();
        }
        if force {
            virt::destroy(&self.uri, name)?;
        } else {
            virt::shutdown(&self.uri, name)?;
        }
        Ok(())
    }

    pub fn status(&self, name: Option<&str>) -> Result<Vec<VmStatus>> {
        match name {
            Some(name) => Ok(vec![self.status_one(name)?]),
            None => {
                let mut rows = Vec::new();
                for name in self.owned_names()? {
                    rows.push(self.status_one(&name)?);
                }
                self.assert_dongle_exclusive(None)?;
                Ok(rows)
            }
        }
    }

    fn status_one(&self, name: &str) -> Result<VmStatus> {
        let ownership = self.require_owned(name)?;
        let _ = self.ensure_backing_seclabel(&ownership);
        let power = virt::domstate(&self.uri, name)?;
        let xml = virt::dumpxml(&self.uri, name)?;
        let facts = xml::inspect(&xml);
        let role_ok =
            crate::network::check_domain(&xml, ownership.role()?, Mode::load(&self.paths)?);
        let dongle = if !facts.usb_ids.is_empty() {
            Some(
                facts
                    .usb_ids
                    .iter()
                    .map(|id| id.display())
                    .collect::<Vec<_>>()
                    .join(","),
            )
        } else if facts
            .nets
            .iter()
            .any(|net| net == crate::profile::WAN_NET || net == crate::network::STANDARD_NET)
        {
            Some(
                if Mode::load(&self.paths)? == Mode::Standard {
                    "host NAT"
                } else {
                    "via-B"
                }
                .to_owned(),
            )
        } else {
            None
        };
        Ok(VmStatus {
            ownership,
            power,
            role_ok,
            dongle,
        })
    }

    /// Live-attach dongle B. The VM must already be running (Boxes or `forge start`).
    /// Does not write the device into the persistent definition, so the next boot is blind.
    pub fn connect_dongle(&self, name: &str, progress: &Progress) -> Result<DongleLink> {
        self.require_dedicated()?;
        let own = self.require_owned(name)?;
        let role = own.role()?;
        if role == Role::WhonixGw {
            return Err(ForgeError::Role(
                "whonix-gateway does not take dongle B inside the VM. B stays on the host as the exit to the router. Stop the workstation, stop the gateway, then `forge start whonix-gateway`."
                    .to_owned(),
            ));
        }
        if !role.may_hold_dongle() {
            return Err(ForgeError::Role(format!(
                "{name} ({}) cannot hold dongle B; only kali",
                role.id()
            )));
        }
        let power = virt::domstate(&self.uri, name)?;
        if !power.is_active() {
            return Err(ForgeError::Role(format!(
                "{name} is {}; open it in Boxes or `forge start {name}` first (connect does not power the VM on)",
                power.as_str()
            )));
        }
        pull::ensure_lab_storage(&self.paths)?;
        self.ensure_backing_seclabel(&own)?;
        pull::verify_file_digest(Path::new(&own.base), &own.base_digest, progress)?;
        self.assert_backing(&own)?;
        let xml = virt::dumpxml(&self.uri, name)?;
        crate::network::check_domain(&xml, role, Mode::load(&self.paths)?)?;
        self.assert_dongle_exclusive(Some(name))?;
        let facts = xml::inspect(&xml);
        let id = match usb::resolve_plugged(&self.paths)? {
            Resolve::Plugged(id) => id,
            Resolve::PinnedMissing(id) => {
                return Err(ForgeError::Host(format!(
                    "dongle B {} is not plugged in",
                    id.display()
                )));
            }
            Resolve::None => {
                return Err(ForgeError::Host("dongle B is not plugged in".to_owned()));
            }
        };
        if facts.usb_ids.contains(&id) {
            return Ok(DongleLink::Already(id.display()));
        }
        if let Some(other) = self.dongle_holder(Some(id), Some(name))? {
            return Err(ForgeError::Role(format!(
                "dongle B {} is already in {other}; `forge disconnect {other}` first",
                id.display()
            )));
        }
        let report = hostnet::enforce()?;
        progress::message(progress, report.trim_end());
        progress::message(
            progress,
            format!("attaching dongle B {} to {name} (live)", id.display()),
        );
        virt::attach_device_live(&self.uri, name, &id.hostdev_xml())?;
        Ok(DongleLink::Connected(id.display()))
    }

    /// Take dongle B back. The VM keeps running. Also strips a persistent hostdev
    /// if one was saved outside Forge.
    pub fn disconnect_dongle(&self, name: &str) -> Result<DongleLink> {
        self.require_dedicated()?;
        let own = self.require_owned(name)?;
        let role = own.role()?;
        let xml = virt::dumpxml(&self.uri, name)?;
        let ids = xml::inspect(&xml).usb_ids;
        if ids.is_empty() {
            if !role.may_hold_dongle() {
                return Err(ForgeError::Role(format!(
                    "{name} ({}) cannot hold dongle B; only kali",
                    role.id()
                )));
            }
            hostnet::enforce()?;
            return Ok(DongleLink::Absent);
        }
        let power = virt::domstate(&self.uri, name)?;
        let inactive = virt::dumpxml_inactive(&self.uri, name).unwrap_or_default();
        let inactive_ids = xml::inspect(&inactive).usb_ids;
        for id in &ids {
            let device = id.hostdev_xml();
            if power.is_active() {
                virt::detach_device_live(&self.uri, name, &device)?;
            }
            if inactive_ids.contains(id) {
                virt::detach_device_config(&self.uri, name, &device)?;
            }
        }
        hostnet::enforce()?;
        Ok(DongleLink::Disconnected)
    }

    pub fn list(&self) -> Result<Vec<InventoryRow>> {
        let owned = self.owned_all()?;
        Ok(Profile::all()
            .into_iter()
            .map(|profile| {
                let image = if pull::base_ready(&self.paths, profile) {
                    "ready"
                } else {
                    "missing"
                };
                let vms = owned
                    .iter()
                    .filter(|o| o.profile == profile.id())
                    .map(|o| o.name.clone())
                    .collect();
                InventoryRow {
                    profile,
                    image,
                    vms,
                }
            })
            .collect())
    }

    pub fn delete(&self, name: &str, dry_run: bool) -> Result<String> {
        let own = self.require_owned(name)?;
        let xml = virt::dumpxml(&self.uri, name).ok();
        if let Some(xml) = &xml {
            if !xml.contains(&own.uuid) || !xml::is_forge_domain(xml) {
                return Err(ForgeError::Ownership(format!(
                    "{name}: libvirt UUID/metadata does not match Forge ownership — refusing delete"
                )));
            }
        } else {
            return Err(ForgeError::Ownership(format!(
                "{name}: no libvirt domain; refusing to guess"
            )));
        }
        let power = virt::domstate(&self.uri, name)?;
        if power.is_active() {
            return Err(ForgeError::Ownership(format!(
                "{name} is {}; stop it first",
                power.as_str()
            )));
        }
        let plan = format!(
            "delete domain {name} uuid {} overlay {} (base {} stays)",
            own.uuid, own.overlay, own.base
        );
        if dry_run {
            return Ok(plan);
        }
        virt::undefine(&self.uri, name)?;
        let overlay = std::path::PathBuf::from(&own.overlay);
        if overlay.exists() {
            fs::remove_file(&overlay)?;
        }
        let _ = fs::remove_file(self.paths.ownership_file(name));
        Ok(plan)
    }

    pub fn clone_vm(&self, src: &str, dst: &str, progress: &Progress) -> Result<Created> {
        validate_vm_name(dst)?;
        let own = self.require_owned(src)?;
        let profile = own.profile()?;
        if profile == Profile::Whonix {
            return Err(ForgeError::InvalidInput(
                "clone of Whonix pair is not supported in Forge 4.2.0".to_owned(),
            ));
        }
        if !matches!(profile.role(), Role::Isolated | Role::OsintClearnet) {
            return Err(ForgeError::NotThisCut(
                "this cut clones isolated and osint-clearnet VMs only".to_owned(),
            ));
        }
        let role = profile.role();
        progress::message(progress, format!("Cloning overlay {src} → {dst}"));
        pull::ensure_lab_storage(&self.paths)?;
        let digest = pull::verify_base_digest(&self.paths, profile, progress)?;
        let src_overlay = std::path::PathBuf::from(&own.overlay);
        let dst_overlay = self.paths.overlay_qcow2(dst);
        if dst_overlay.exists() || virt::domain_exists(&self.uri, dst)? {
            return Err(ForgeError::AlreadyExists(format!("target {dst} exists")));
        }
        fs::copy(&src_overlay, &dst_overlay)?;
        let uuid = uuid::Uuid::new_v4().to_string();
        let spec = DomainSpec {
            name: dst,
            uuid: &uuid,
            profile: profile.id(),
            role,
            overlay: &dst_overlay.to_string_lossy(),
            base: &own.base,
            base_digest: &digest,
            memory_mib: profile.memory_mib(),
            vcpus: profile.vcpus(),
        };
        let xml = xml::domain_xml_with(
            &spec,
            crate::security::Policy::for_paths(&self.paths)?,
            Mode::load(&self.paths)?,
        );
        let ownership = Ownership {
            name: dst.to_owned(),
            uuid: uuid.clone(),
            profile: profile.id().to_owned(),
            role: role.id().to_owned(),
            overlay: dst_overlay.display().to_string(),
            base: own.base.clone(),
            base_digest: digest,
            libvirt_uri: self.uri.clone(),
        };
        ownership::write_json_atomic(&self.paths.ownership_file(dst), &ownership)?;
        virt::define_xml(&self.uri, &xml)?;
        Ok(Created {
            name: dst.to_owned(),
            uuid,
            xml,
        })
    }

    pub fn dump_xml(&self, name: &str) -> Result<String> {
        let own = self.require_owned(name)?;
        let xml = virt::dumpxml(&self.uri, name)?;
        let mut out = xml.clone();
        out.push_str("\n<!-- Forge role check: ");
        match crate::network::check_domain(&xml, own.role()?, Mode::load(&self.paths)?) {
            Ok(()) => out.push_str("ok -->\n"),
            Err(error) => out.push_str(&format!("{error} -->\n")),
        }
        Ok(out)
    }

    fn require_owned(&self, name: &str) -> Result<Ownership> {
        let path = self.paths.ownership_file(name);
        if !path.is_file() {
            return Err(ForgeError::Ownership(format!(
                "{name} is not a Forge VM (no ownership file)"
            )));
        }
        let own: Ownership = ownership::read_json(&path)?;
        if own.name != name {
            return Err(ForgeError::Ownership(format!(
                "ownership name {} != {name}",
                own.name
            )));
        }
        if own.libvirt_uri != SYSTEM_URI && !own.libvirt_uri.is_empty() {
            return Err(ForgeError::Ownership(format!(
                "{name} recorded URI {} — Forge uses {SYSTEM_URI}",
                own.libvirt_uri
            )));
        }
        Ok(own)
    }

    fn owned_names(&self) -> Result<Vec<String>> {
        Ok(self.owned_all()?.into_iter().map(|o| o.name).collect())
    }

    fn owned_all(&self) -> Result<Vec<Ownership>> {
        let dir = self.paths.ownership_root();
        if !dir.is_dir() {
            return Ok(Vec::new());
        }
        let mut out = Vec::new();
        for entry in fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("json") {
                continue;
            }
            let own: Ownership = ownership::read_json(&path)?;
            if path.file_stem().and_then(|s| s.to_str()) != Some(own.name.as_str()) {
                return Err(ForgeError::Ownership(
                    "ownership filename differs from VM name".to_owned(),
                ));
            }
            validate_vm_name(&own.name)?;
            out.push(own);
        }
        out.sort_by(|a, b| a.name.cmp(&b.name));
        Ok(out)
    }

    fn ensure_backing_seclabel(&self, own: &Ownership) -> Result<()> {
        if !virt::domain_exists(&self.uri, &own.name)? {
            return Ok(());
        }
        let xml = virt::dumpxml(&self.uri, &own.name)?;
        if crate::security::validate_domain(&xml, crate::security::Policy::for_paths(&self.paths)?)
            .is_ok()
        {
            return Ok(());
        }
        if virt::domstate(&self.uri, &own.name)?.is_active() {
            return Err(ForgeError::Role(
                "stop the VM before repairing its security XML".to_owned(),
            ));
        }
        self.redefine_owned(own)
    }

    fn ensure_role_shape(&self, own: &Ownership) -> Result<()> {
        if !virt::domain_exists(&self.uri, &own.name)? {
            return Ok(());
        }
        let xml = virt::dumpxml(&self.uri, &own.name)?;
        if crate::network::check_domain(&xml, own.role()?, Mode::load(&self.paths)?).is_ok() {
            return Ok(());
        }
        let power = virt::domstate(&self.uri, &own.name)?;
        if power.is_active() {
            return Err(ForgeError::Role(format!(
                "{} is running with the old network layout. Stop it, then start it again.",
                own.name
            )));
        }
        self.redefine_owned(own)
    }

    fn redefine_owned(&self, own: &Ownership) -> Result<()> {
        let profile = own.profile()?;
        let memory = if own.name == WHONIX_WS_NAME {
            profile.workstation_memory_mib()
        } else {
            profile.memory_mib()
        };
        let spec = DomainSpec {
            name: &own.name,
            uuid: &own.uuid,
            profile: profile.id(),
            role: own.role()?,
            overlay: &own.overlay,
            base: &own.base,
            base_digest: &own.base_digest,
            memory_mib: memory,
            vcpus: profile.vcpus(),
        };
        virt::define_xml(
            &self.uri,
            &xml::domain_xml_with(
                &spec,
                crate::security::Policy::for_paths(&self.paths)?,
                Mode::load(&self.paths)?,
            ),
        )?;
        Ok(())
    }

    fn prepare_standard_networks(&self) -> Result<()> {
        virt::ensure_standard_networks(&self.uri)?;
        // This handles firewalld forwarding only; never touches NetworkManager or USB.
        hostnet::allow_libvirt_forward()
    }

    fn prepare_gateway_exit(&self, progress: &Progress) -> Result<()> {
        hostnet::allow_libvirt_forward()?;
        let report = hostnet::enforce()?;
        progress::message(progress, report.trim_end());
        virt::ensure_whonix_net(&self.uri)?;
        match self.wait_dongle_iface()? {
            Some(iface) => match hostnet::lease_usb(&iface) {
                Ok(router) => {
                    progress::message(
                        progress,
                        format!(
                            "dongle B {iface} leased from the router ({router}); Fedora keeps cable A"
                        ),
                    );
                    virt::ensure_wan_net(&self.uri, Some(&iface))?;
                }
                Err(error) => {
                    let _ = hostnet::release_usb();
                    virt::ensure_wan_net(&self.uri, None)?;
                    return Err(ForgeError::Host(format!(
                        "dongle B exit preparation failed ({error}); forge-wan isolated, gateway not started"
                    )));
                }
            },
            None => {
                progress::message(
                    progress,
                    "dongle B not plugged; workstation can reach the gateway, the gateway has no router",
                );
                let _ = hostnet::release_usb();
                virt::ensure_wan_net(&self.uri, None)?;
            }
        }
        Ok(())
    }

    fn wait_dongle_iface(&self) -> Result<Option<String>> {
        let mut resolved = usb::resolve_plugged(&self.paths)?;
        if matches!(resolved, Resolve::None) {
            return Ok(None);
        }
        for _ in 0..20 {
            if let Resolve::Plugged(id) = resolved {
                if let Some(iface) = usb::iface_for(id)? {
                    return Ok(Some(iface));
                }
            }
            std::thread::sleep(std::time::Duration::from_millis(250));
            resolved = usb::resolve_plugged(&self.paths)?;
            if matches!(resolved, Resolve::None) {
                return Ok(None);
            }
        }
        Ok(None)
    }

    fn assert_one_wan(&self, own: &Ownership) -> Result<()> {
        if Mode::load(&self.paths)? == Mode::Standard {
            return Ok(());
        }
        let other = match own.role()? {
            Role::WhonixGw => "kali",
            Role::OsintClearnet => WHONIX_GW_NAME,
            _ => return Ok(()),
        };
        if virt::domain_exists(&self.uri, other)? {
            let power = virt::domstate(&self.uri, other).unwrap_or(VmPower::Shutoff);
            if power.is_active() {
                return Err(ForgeError::Role(format!(
                    "one WAN guest at a time; stop {other} before starting {}",
                    own.name
                )));
            }
        }
        Ok(())
    }

    fn assert_backing(&self, own: &Ownership) -> Result<()> {
        let overlay = std::path::PathBuf::from(&own.overlay);
        let backing = virt::qemu_img_backing(&overlay)?
            .ok_or_else(|| ForgeError::Verify(format!("{} has no backing file", own.name)))?;
        let base = std::path::PathBuf::from(&own.base);
        let backing_canon = std::fs::canonicalize(&backing).unwrap_or_else(|_| backing.into());
        let base_canon = std::fs::canonicalize(&base).unwrap_or(base);
        if backing_canon != base_canon {
            return Err(ForgeError::Verify(format!(
                "{} overlay backing {} is not the recorded base {}",
                own.name,
                backing_canon.display(),
                base_canon.display()
            )));
        }
        Ok(())
    }

    fn maybe_attach_dongle_b(&self, name: &str, role: Role, progress: &Progress) -> Result<()> {
        if Mode::load(&self.paths)? == Mode::Standard || role != Role::OsintClearnet {
            return Ok(());
        }
        match usb::resolve_plugged(&self.paths)? {
            Resolve::Plugged(id) => {
                if let Some(other) = self.dongle_holder(Some(id), Some(name))? {
                    progress::message(
                        progress,
                        format!("dongle B {} already in {other}; not stealing", id.display()),
                    );
                    return Ok(());
                }
                let live = virt::dumpxml(&self.uri, name).unwrap_or_default();
                if xml::inspect(&live).usb_ids.contains(&id) {
                    progress::message(
                        progress,
                        format!("dongle B {} is already in {name}", id.display()),
                    );
                    return Ok(());
                }
                progress::message(
                    progress,
                    format!("attaching dongle B {} to {name} (live)", id.display()),
                );
                if let Err(error) = virt::attach_device_live(&self.uri, name, &id.hostdev_xml()) {
                    let live = virt::dumpxml(&self.uri, name).unwrap_or_default();
                    if xml::inspect(&live).usb_ids.contains(&id) {
                        return Ok(());
                    }
                    return Err(error);
                }
            }
            Resolve::PinnedMissing(id) => {
                progress::message(
                    progress,
                    format!(
                        "dongle B {} not plugged; starting without WAN",
                        id.display()
                    ),
                );
            }
            Resolve::None => {
                progress::message(progress, "dongle B not plugged; starting without WAN");
            }
        }
        Ok(())
    }

    fn maybe_detach_dongle_b(&self, name: &str, role: Role) -> Result<()> {
        if Mode::load(&self.paths)? == Mode::Standard
            || !matches!(role, Role::WhonixGw | Role::OsintClearnet)
        {
            return Ok(());
        }
        let Ok(xml) = virt::dumpxml(&self.uri, name) else {
            return Ok(());
        };
        for id in xml::inspect(&xml).usb_ids {
            let _ = virt::detach_device_live(&self.uri, name, &id.hostdev_xml());
        }
        Ok(())
    }

    fn dongle_holder(&self, id: Option<UsbId>, except: Option<&str>) -> Result<Option<String>> {
        if Mode::load(&self.paths)? == Mode::Standard {
            return Ok(None);
        }
        let names = virt::list_all_names(&self.uri).unwrap_or_default();
        for name in names {
            if except == Some(name.as_str()) {
                continue;
            }
            let Ok(xml) = virt::dumpxml(&self.uri, &name) else {
                continue;
            };
            let facts = xml::inspect(&xml);
            let hit = match id {
                Some(id) => facts.usb_ids.contains(&id),
                None => facts.hostdev_usb > 0,
            };
            if hit {
                return Ok(Some(name));
            }
        }
        Ok(None)
    }

    fn assert_dongle_exclusive(&self, starting: Option<&str>) -> Result<()> {
        if Mode::load(&self.paths)? == Mode::Standard {
            return Ok(());
        }
        let names = virt::list_all_names(&self.uri).unwrap_or_default();
        let mut holders: Vec<(String, String)> = Vec::new();
        for name in names {
            let Ok(xml) = virt::dumpxml(&self.uri, &name) else {
                continue;
            };
            for id in xml::inspect(&xml).usb_ids {
                holders.push((name.clone(), id.display()));
            }
        }
        let _ = starting;
        if holders.len() <= 1 {
            return Ok(());
        }
        let mut by_id: std::collections::BTreeMap<String, Vec<String>> =
            std::collections::BTreeMap::new();
        for (vm, id) in holders {
            by_id.entry(id).or_default().push(vm);
        }
        let clashes: Vec<String> = by_id
            .into_iter()
            .filter(|(_, vms)| vms.len() > 1)
            .map(|(id, vms)| format!("{id} in {}", vms.join("+")))
            .collect();
        if clashes.is_empty() {
            Ok(())
        } else {
            Err(ForgeError::Role(format!(
                "dongle B in more than one VM: {}",
                clashes.join("; ")
            )))
        }
    }

    fn require_dedicated(&self) -> Result<()> {
        if Mode::load(&self.paths)? != Mode::Dedicated {
            return Err(ForgeError::InvalidInput("USB uplink and cable controls require dedicated mode; standard mode uses the host connection".to_owned()));
        }
        Ok(())
    }

    pub fn network_mode(&self) -> Result<Mode> {
        Mode::load(&self.paths)
    }

    pub fn setup_network(&self, requested: Option<Mode>) -> Result<Mode> {
        let mode = requested.map_or_else(|| Mode::load(&self.paths), Ok)?;
        if !virt::virsh(&self.uri, &["list", "--name"])?
            .trim()
            .is_empty()
        {
            return Err(ForgeError::Role(
                "stop all QEMU guests before setting up or switching network mode".to_owned(),
            ));
        }
        let owned = self.owned_all()?;
        // Resolve all records before committing a new mode.
        for own in &owned {
            own.profile()?;
            own.role()?;
            self.require_owned(&own.name)?;
            let xml = virt::dumpxml(&self.uri, &own.name)?;
            crate::hook::verify_owned_domain(&xml, own)?;
        }
        crate::hook::ensure_installed_for(&self.paths, mode)?;
        if mode == Mode::Standard {
            self.prepare_standard_networks()?;
        } else {
            virt::ensure_whonix_net(&self.uri)?;
            virt::ensure_wan_net(&self.uri, None)?;
        }
        for own in &owned {
            if virt::domstate(&self.uri, &own.name)?.is_active() {
                return Err(ForgeError::Role(
                    "a VM started during setup; stop all guests and retry".to_owned(),
                ));
            }
            self.redefine_owned(own)?;
        }
        if Mode::installed()? != mode {
            return Err(ForgeError::Host(
                "network mode changed concurrently; rerun forge setup with all guests stopped"
                    .to_owned(),
            ));
        }
        Ok(mode)
    }

    pub fn usb_report(&self) -> String {
        usb::format_dev_list(&self.paths)
    }

    pub fn install_hook(&self) -> Result<()> {
        crate::hook::ensure_installed(&self.paths)
    }

    pub fn enforce_cables(&self) -> Result<String> {
        self.require_dedicated()?;
        hostnet::enforce()
    }
}

impl crate::prepare::Backend for Forge {
    fn check_stopped(&self) -> Result<()> {
        if !virt::virsh(&self.uri, &["list", "--name"])?
            .trim()
            .is_empty()
        {
            return Err(ForgeError::Role(
                "stop all QEMU guests before prepare --all".to_owned(),
            ));
        }
        Ok(())
    }
    fn setup(&self) -> Result<()> {
        <Self as crate::prepare::Backend>::check_stopped(self)?;
        // Recover the narrow interruption window after ownership was written but
        // before virsh define completed. Never adopt an unrecorded overlay/domain.
        for own in self.owned_all()? {
            if !virt::domain_exists(&self.uri, &own.name)? {
                let profile = own.profile()?;
                let expected_role = if profile == Profile::Whonix && own.name == WHONIX_WS_NAME {
                    Role::WhonixWs
                } else {
                    profile.role()
                };
                if own.role()? != expected_role
                    || (profile == Profile::Whonix
                        && ![WHONIX_GW_NAME, WHONIX_WS_NAME].contains(&own.name.as_str()))
                {
                    return Err(ForgeError::Ownership(
                        "unfinished VM has an unexpected profile/role".to_owned(),
                    ));
                }
                let expected = if profile == Profile::Whonix && own.name == WHONIX_WS_NAME {
                    self.paths.named_base(WHONIX_WS_NAME)
                } else {
                    self.paths.base_qcow2(profile)
                };
                if Path::new(&own.base) != expected
                    || Path::new(&own.overlay) != self.paths.overlay_qcow2(&own.name)
                {
                    return Err(ForgeError::Ownership(
                        "unfinished VM paths differ from canonical Forge storage".to_owned(),
                    ));
                }
                self.assert_backing(&own)?;
                pull::verify_file_digest(Path::new(&own.base), &own.base_digest, &progress::noop)?;
                self.redefine_owned(&own)?;
            }
        }
        self.setup_network(None)?;
        pull::ensure_lab_storage(&self.paths)
    }
    fn base_ready(&self, profile: Profile) -> bool {
        pull::base_ready(&self.paths, profile)
    }
    fn has_references(&self, profile: Profile) -> Result<bool> {
        Ok(self
            .owned_all()?
            .iter()
            .any(|own| own.profile == profile.id())
            || if profile == Profile::Whonix {
                self.paths.overlay_qcow2(WHONIX_GW_NAME).exists()
                    || self.paths.overlay_qcow2(WHONIX_WS_NAME).exists()
            } else {
                self.paths.overlay_qcow2(profile.default_name()).exists()
            })
    }
    fn pull(&self, profile: Profile, sift_ova: Option<&Path>, progress: &Progress) -> Result<()> {
        if profile == Profile::Sift {
            pull::pull_sift_from(&self.paths, sift_ova, progress)?;
        } else {
            pull::pull(&self.paths, profile, progress)?;
        }
        Ok(())
    }
    fn verify(&self, profile: Profile, progress: &Progress) -> Result<()> {
        let proof: crate::ownership::BaseProof =
            ownership::read_json(&self.paths.proof_file(profile))?;
        if proof.profile != profile.id()
            || Path::new(&proof.base_path) != self.paths.base_qcow2(profile)
            || (profile == Profile::Whonix
                && (proof.extra.len() != 1
                    || proof.extra[0].name != WHONIX_WS_NAME
                    || Path::new(&proof.extra[0].path) != self.paths.named_base(WHONIX_WS_NAME)))
        {
            return Err(ForgeError::Verify(
                "base proof differs from canonical profile paths".to_owned(),
            ));
        }
        pull::verify_base_digest(&self.paths, profile, progress)?;
        Ok(())
    }
    fn ensure_vms(&self, profile: Profile, progress: &Progress) -> Result<()> {
        let proof: crate::ownership::BaseProof =
            ownership::read_json(&self.paths.proof_file(profile))?;
        let mut specs = vec![(
            profile.default_name(),
            profile.role(),
            proof.base_path.as_str(),
            proof.base_digest.as_str(),
            profile.memory_mib(),
        )];
        if profile == Profile::Whonix {
            specs[0].0 = WHONIX_GW_NAME;
            specs.push((
                WHONIX_WS_NAME,
                Role::WhonixWs,
                &proof.extra[0].path,
                &proof.extra[0].digest,
                profile.workstation_memory_mib(),
            ));
        }
        for (name, role, base, digest, memory) in specs {
            if virt::domain_exists(&self.uri, name)? {
                let own = self.require_owned(name)?;
                crate::hook::verify_owned_domain(&virt::dumpxml(&self.uri, name)?, &own)?;
                if own.profile != profile.id()
                    || own.role()? != role
                    || own.base != base
                    || own.base_digest != digest
                {
                    return Err(ForgeError::Ownership(format!(
                        "{name} does not match the verified profile base; refusing to overwrite existing VM data"
                    )));
                }
                self.assert_backing(&own)?;
                progress::message(
                    progress,
                    format!("{name} already exists; keeping its overlay"),
                );
                continue;
            }
            self.create_one(
                profile,
                name,
                role,
                Path::new(base),
                Some((digest, memory)),
                false,
                progress,
            )?;
        }
        Ok(())
    }
}

fn validate_vm_name(name: &str) -> Result<()> {
    if name.len() > 48
        || !name
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-')
        || name.starts_with('-')
        || name.ends_with('-')
    {
        return Err(ForgeError::InvalidInput(format!(
            "bad VM name '{name}' (ascii lowercase, digits, hyphen)"
        )));
    }
    Ok(())
}

#[must_use]
pub fn format_list(rows: &[InventoryRow]) -> String {
    let mut out = format!("{:<10} {:<12} {}\n", "profile", "image", "vms");
    for row in rows {
        let vms = if row.vms.is_empty() {
            "—".to_owned()
        } else {
            row.vms.join(", ")
        };
        out.push_str(&format!(
            "{:<10} {:<12} {}\n",
            row.profile.id(),
            row.image,
            vms
        ));
    }
    out
}

#[must_use]
pub fn format_status(rows: &[VmStatus]) -> String {
    let mut out = String::new();
    for row in rows {
        out.push_str(&format!(
            "{:<18} {:<10} {:<14} {}",
            row.ownership.name,
            row.ownership.profile,
            row.power.as_str(),
            row.ownership.role
        ));
        let dongle = row.dongle.as_deref().unwrap_or("off");
        match &row.role_ok {
            Ok(()) => out.push_str(&format!("  role=ok  b={dongle}\n")),
            Err(error) => out.push_str(&format!("  ROLE FAIL: {error}  b={dongle}\n")),
        }
    }
    if out.is_empty() {
        out.push_str("No Forge VMs.\n");
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dry_run_create_isolated_xml() {
        let dir = std::env::temp_dir().join(format!("forge-lab-{}", uuid::Uuid::new_v4()));
        let paths = ForgePaths::under(dir.clone(), false);
        paths.ensure_user().unwrap();
        let src = dir.join("src.qcow2");
        crate::cmd::run(
            "qemu-img",
            &["create", "-f", "qcow2", src.to_str().unwrap(), "4M"],
        )
        .unwrap();
        crate::pull::install_base(
            &paths,
            Profile::Tsurugi,
            &src,
            crate::ownership::BaseProof {
                profile: "tsurugi".into(),
                source_url: "test".into(),
                artifact: "src.qcow2".into(),
                upstream_checksum: "x".into(),
                upstream_kind: "test".into(),
                base_digest: String::new(),
                base_path: String::new(),
                extra: Vec::new(),
            },
            &progress::noop,
        )
        .unwrap();
        let forge = Forge::open_paths(paths).unwrap();
        let created = forge
            .create(Profile::Tsurugi, None, true, &progress::noop)
            .unwrap();
        assert_eq!(created[0].name, "tsurugi");
        assert!(!created[0].xml.contains("<interface"));
        crate::network::check_domain(&created[0].xml, Role::Isolated, Mode::Standard).unwrap();
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn dry_run_create_kali_osint() {
        let dir = std::env::temp_dir().join(format!("forge-lab-{}", uuid::Uuid::new_v4()));
        let paths = ForgePaths::under(dir.clone(), false);
        paths.ensure_user().unwrap();
        let src = dir.join("src.qcow2");
        crate::cmd::run(
            "qemu-img",
            &["create", "-f", "qcow2", src.to_str().unwrap(), "4M"],
        )
        .unwrap();
        crate::pull::install_base(
            &paths,
            Profile::Kali,
            &src,
            crate::ownership::BaseProof {
                profile: "kali".into(),
                source_url: "test".into(),
                artifact: "src.qcow2".into(),
                upstream_checksum: "x".into(),
                upstream_kind: "test".into(),
                base_digest: String::new(),
                base_path: String::new(),
                extra: Vec::new(),
            },
            &progress::noop,
        )
        .unwrap();
        let forge = Forge::open_paths(paths).unwrap();
        let created = forge
            .create(Profile::Kali, None, true, &progress::noop)
            .unwrap();
        assert_eq!(created[0].name, "kali");
        assert!(created[0].xml.contains("forge-standard"));
        assert!(created[0].xml.contains("osint-clearnet"));
        crate::network::check_domain(&created[0].xml, Role::OsintClearnet, Mode::Standard).unwrap();
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn dry_run_create_sift_isolated() {
        let dir = std::env::temp_dir().join(format!("forge-lab-{}", uuid::Uuid::new_v4()));
        let paths = ForgePaths::under(dir.clone(), false);
        paths.ensure_user().unwrap();
        let src = dir.join("src.qcow2");
        crate::cmd::run(
            "qemu-img",
            &["create", "-f", "qcow2", src.to_str().unwrap(), "4M"],
        )
        .unwrap();
        crate::pull::install_base(
            &paths,
            Profile::Sift,
            &src,
            crate::ownership::BaseProof {
                profile: "sift".into(),
                source_url: "test".into(),
                artifact: "src.qcow2".into(),
                upstream_checksum: "x".into(),
                upstream_kind: "test".into(),
                base_digest: String::new(),
                base_path: String::new(),
                extra: Vec::new(),
            },
            &progress::noop,
        )
        .unwrap();
        let forge = Forge::open_paths(paths).unwrap();
        let created = forge
            .create(Profile::Sift, None, true, &progress::noop)
            .unwrap();
        assert_eq!(created[0].name, "sift");
        assert!(!created[0].xml.contains("<interface"));
        crate::network::check_domain(&created[0].xml, Role::Isolated, Mode::Standard).unwrap();
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn dry_run_create_whonix_pair() {
        let dir = std::env::temp_dir().join(format!("forge-lab-{}", uuid::Uuid::new_v4()));
        let paths = ForgePaths::under(dir.clone(), false);
        paths.ensure_user().unwrap();
        let (gw, ws) = paths.whonix_bases();
        crate::cmd::run(
            "qemu-img",
            &["create", "-f", "qcow2", gw.to_str().unwrap(), "4M"],
        )
        .unwrap();
        crate::cmd::run(
            "qemu-img",
            &["create", "-f", "qcow2", ws.to_str().unwrap(), "4M"],
        )
        .unwrap();
        let gw_digest = format!(
            "sha256:{}",
            crate::hash::sha256_file(&gw, &progress::noop).unwrap()
        );
        let ws_digest = format!(
            "sha256:{}",
            crate::hash::sha256_file(&ws, &progress::noop).unwrap()
        );
        crate::ownership::write_json_atomic(
            &paths.proof_file(Profile::Whonix),
            &crate::ownership::BaseProof {
                profile: "whonix".into(),
                source_url: "test".into(),
                artifact: "bundle".into(),
                upstream_checksum: "x".into(),
                upstream_kind: "test".into(),
                base_digest: gw_digest,
                base_path: gw.display().to_string(),
                extra: vec![crate::ownership::ExtraDisk {
                    name: "whonix-workstation".into(),
                    path: ws.display().to_string(),
                    digest: ws_digest,
                }],
            },
        )
        .unwrap();
        let forge = Forge::open_paths(paths).unwrap();
        let created = forge
            .create(Profile::Whonix, None, true, &progress::noop)
            .unwrap();
        assert_eq!(created.len(), 2);
        assert_eq!(created[0].name, "whonix-gateway");
        assert_eq!(created[1].name, "whonix-workstation");
        crate::network::check_domain(&created[0].xml, Role::WhonixGw, Mode::Standard).unwrap();
        crate::network::check_domain(&created[1].xml, Role::WhonixWs, Mode::Standard).unwrap();
        assert!(created[0].xml.contains("forge-whonix"));
        assert!(!created[0].xml.contains("type='user'"));
        let _ = fs::remove_dir_all(dir);
    }
}
