#[cfg(test)]
use crate::error::Result;
use crate::profile::{METADATA_NS, WAN_NET, WHONIX_NET};
use crate::role::Role;

#[must_use]
pub fn escape(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

#[derive(Debug, Clone)]
pub struct DomainSpec<'a> {
    pub name: &'a str,
    pub uuid: &'a str,
    pub profile: &'a str,
    pub role: Role,
    pub overlay: &'a str,
    pub base: &'a str,
    pub base_digest: &'a str,
    pub memory_mib: u32,
    pub vcpus: u32,
}

#[must_use]
#[cfg(test)]
pub fn domain_xml(spec: &DomainSpec<'_>) -> String {
    domain_xml_for(spec, crate::security::Policy::Selinux)
}

#[cfg(test)]
pub fn domain_xml_for(spec: &DomainSpec<'_>, policy: crate::security::Policy) -> String {
    domain_xml_with(spec, policy, crate::network::Mode::Dedicated)
}

pub fn domain_xml_with(
    spec: &DomainSpec<'_>,
    policy: crate::security::Policy,
    mode: crate::network::Mode,
) -> String {
    let name = escape(spec.name);
    let uuid = escape(spec.uuid);
    let overlay = escape(spec.overlay);
    let base = escape(spec.base);
    let profile = escape(spec.profile);
    let digest = escape(spec.base_digest);
    let role = spec.role.id();
    let nets = if mode == crate::network::Mode::Standard && spec.role == Role::OsintClearnet {
        format!(
            "    <interface type='network'><source network='{}'/><model type='virtio'/></interface>\n",
            crate::network::STANDARD_NET
        )
    } else {
        network_xml(spec.role)
    };
    let model = policy.model();
    let base_security = if policy == crate::security::Policy::Selinux {
        "          <seclabel model='dac' relabel='no'/>\n          <seclabel model='selinux' relabel='no'/>"
    } else {
        "          <seclabel model='dac' relabel='no'/>"
    };
    format!(
        "\
<domain type='kvm'>
  <seclabel type='dynamic' model='{model}' relabel='yes'/>
  <name>{name}</name>
  <uuid>{uuid}</uuid>
  <metadata>
    <forge:forge xmlns:forge='{METADATA_NS}'>
      <forge:network-mode>{mode}</forge:network-mode>
      <forge:profile>{profile}</forge:profile>
      <forge:role>{role}</forge:role>
      <forge:base-digest>{digest}</forge:base-digest>
      <forge:overlay>{overlay}</forge:overlay>
    </forge:forge>
  </metadata>
  <memory unit='MiB'>{memory}</memory>
  <currentMemory unit='MiB'>{memory}</currentMemory>
  <vcpu placement='static'>{vcpus}</vcpu>
  <os>
    <type arch='x86_64' machine='q35'>hvm</type>
    <boot dev='hd'/>
  </os>
  <features>
    <acpi/>
    <apic/>
  </features>
  <cpu mode='host-passthrough' check='none'/>
  <clock offset='utc'/>
  <on_poweroff>destroy</on_poweroff>
  <on_reboot>restart</on_reboot>
  <on_crash>destroy</on_crash>
  <devices>
    <disk type='file' device='disk'>
      <driver name='qemu' type='qcow2' discard='unmap'/>
      <source file='{overlay}'/>
      <backingStore type='file'>
        <format type='qcow2'/>
        <source file='{base}'>
{base_security}
        </source>
        <backingStore/>
      </backingStore>
      <target dev='vda' bus='virtio'/>
    </disk>
{nets}    <serial type='pty'>
      <target port='0'/>
    </serial>
    <console type='pty'>
      <target type='serial' port='0'/>
    </console>
    <channel type='spicevmc'>
      <target type='virtio' name='com.redhat.spice.0'/>
    </channel>
    <input type='tablet' bus='usb'/>
    <graphics type='spice' autoport='yes'>
      <listen type='address' address='127.0.0.1'/>
    </graphics>
    <video>
      <model type='virtio' heads='1' primary='yes'/>
    </video>
    <controller type='usb' model='qemu-xhci'/>
    <rng model='virtio'>
      <backend model='random'>/dev/urandom</backend>
    </rng>
  </devices>
</domain>
",
        memory = spec.memory_mib,
        vcpus = spec.vcpus,
    )
}

fn network_xml(role: Role) -> String {
    match role {
        Role::Isolated => String::new(),
        Role::WhonixWs => format!(
            "    <interface type='network'>
      <source network='{WHONIX_NET}'/>
      <model type='virtio'/>
    </interface>
"
        ),
        Role::WhonixGw => format!(
            "    <interface type='network'>
      <source network='{WAN_NET}'/>
      <model type='virtio'/>
    </interface>
    <interface type='network'>
      <source network='{WHONIX_NET}'/>
      <model type='virtio'/>
    </interface>
"
        ),
        Role::OsintClearnet => {
            "    <!-- USB dongle B is attached as hostdev by the operator / virt-manager spare -->\n"
                .to_owned()
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct XmlFacts {
    /// Libvirt `<source network='...'>` values, in XML order. Order is eth0, eth1, …
    pub nets: Vec<String>,
    pub hostdev_usb: usize,
    pub usb_ids: Vec<crate::usb::UsbId>,
    pub disk_files: Vec<String>,
    pub forge_profile: Option<String>,
    pub forge_role: Option<String>,
    pub forge_digest: Option<String>,
    pub forge_overlay: Option<String>,
}

#[must_use]
pub fn inspect(xml: &str) -> XmlFacts {
    let lower = xml.to_ascii_lowercase();
    let mut facts = XmlFacts {
        hostdev_usb: hostdev_type_count(&lower, "usb"),
        ..XmlFacts::default()
    };
    facts.usb_ids = crate::usb::ids_in_xml(xml);
    facts.nets = network_sources(xml);
    facts.disk_files = source_files(xml);
    facts.forge_profile = meta_text(xml, "profile");
    facts.forge_role = meta_text(xml, "role");
    facts.forge_digest = meta_text(xml, "base-digest");
    facts.forge_overlay = meta_text(xml, "overlay");
    facts
}

fn hostdev_type_count(xml: &str, kind: &str) -> usize {
    let quoted = format!("type='{kind}'");
    let double = format!("type=\"{kind}\"");
    let mut n = 0;
    let mut rest = xml;
    while let Some(i) = rest.find("<hostdev") {
        let chunk = &rest[i..];
        let end = chunk.find('>').unwrap_or(chunk.len());
        let head = &chunk[..end];
        if head.contains(&quoted) || head.contains(&double) {
            n += 1;
        }
        rest = &chunk[1..];
    }
    n
}

fn network_sources(xml: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = xml;
    while let Some(i) = rest.find("<source") {
        let chunk = &rest[i..];
        if let Some(net) = attr(chunk, "network") {
            out.push(net);
        }
        rest = &chunk[1..];
    }
    out
}

fn source_files(xml: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = xml;
    while let Some(i) = rest.find("<source") {
        let chunk = &rest[i..];
        if let Some(file) = attr(chunk, "file") {
            out.push(file);
        }
        rest = &chunk[1..];
    }
    out
}

fn attr(chunk: &str, name: &str) -> Option<String> {
    let head = &chunk[..chunk.find('>').unwrap_or(chunk.len())];
    for quote in ['\'', '"'] {
        let pat = format!("{name}={quote}");
        if let Some(i) = head.find(&pat) {
            let rest = &chunk[i + pat.len()..];
            if let Some(end) = rest.find(quote) {
                return Some(rest[..end].to_owned());
            }
        }
    }
    None
}

fn meta_text(xml: &str, tag: &str) -> Option<String> {
    let open = format!("<forge:{tag}>");
    let close = format!("</forge:{tag}>");
    let start = xml.find(&open)? + open.len();
    let end = xml[start..].find(&close)? + start;
    Some(xml[start..end].trim().to_owned())
}

#[cfg(test)]
pub fn check_role(xml: &str, expected: Role) -> Result<()> {
    crate::network::check_domain(xml, expected, crate::network::Mode::Dedicated)
}

#[must_use]
pub fn is_forge_domain(xml: &str) -> bool {
    xml.contains(METADATA_NS)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn isolated_spec() -> DomainSpec<'static> {
        DomainSpec {
            name: "tsurugi",
            uuid: "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            profile: "tsurugi",
            role: Role::Isolated,
            overlay: "/var/lib/forge/vms/tsurugi.qcow2",
            base: "/var/lib/forge/bases/tsurugi.qcow2",
            base_digest: "sha256:deadbeef",
            memory_mib: 8192,
            vcpus: 4,
        }
    }

    #[test]
    fn security_xml_is_specific_to_the_host_driver() {
        for policy in [
            crate::security::Policy::Selinux,
            crate::security::Policy::Apparmor,
        ] {
            let xml = domain_xml_for(&isolated_spec(), policy);
            crate::security::validate_domain(&xml, policy).unwrap();
            let foreign = if policy == crate::security::Policy::Selinux {
                crate::security::Policy::Apparmor
            } else {
                crate::security::Policy::Selinux
            };
            assert!(crate::security::validate_domain(&xml, foreign).is_err());
            for tampered in [
                xml.replace("type='dynamic'", "type='none'"),
                xml.replace("model='dac' relabel='no'", "model='dac' relabel='yes'"),
                xml.replace("<backingStore type='file'>", "<!-- <backingStore type='file'> --> <unrelated>"),
                xml.replace("<source file='/var/lib/forge/vms/tsurugi.qcow2'/>", "<source file='/var/lib/forge/vms/tsurugi.qcow2'><seclabel model='dac' relabel='no'/></source>"),
            ] {
                assert!(crate::security::validate_domain(&tampered, policy).is_err());
            }
            // Attribute formatting is normalized by libvirt; quotes and spacing are immaterial.
            crate::security::validate_domain(&xml.replace('\'', "\""), policy).unwrap();
        }
    }

    #[test]
    fn comment_cannot_stand_in_for_a_base_security_label() {
        let xml = domain_xml_for(&isolated_spec(), crate::security::Policy::Apparmor).replace(
            "<seclabel model='dac' relabel='no'/>",
            "<!-- <seclabel model='dac' relabel='no'/> -->",
        );
        assert!(crate::security::validate_domain(&xml, crate::security::Policy::Apparmor).is_err());
    }

    #[test]
    fn both_modes_keep_the_workstation_private_and_forensic_guests_offline() {
        for mode in [
            crate::network::Mode::Standard,
            crate::network::Mode::Dedicated,
        ] {
            for role in [
                Role::Isolated,
                Role::OsintClearnet,
                Role::WhonixGw,
                Role::WhonixWs,
            ] {
                let mut spec = isolated_spec();
                spec.role = role;
                let xml = domain_xml_with(&spec, crate::security::Policy::Selinux, mode);
                crate::network::check_domain(&xml, role, mode).unwrap();
                if role == Role::Isolated {
                    assert!(!xml.contains("<interface"));
                }
                if role == Role::WhonixWs {
                    assert!(!xml.contains("network='forge-standard'"));
                    assert!(!xml.contains("network='forge-wan'"));
                    assert!(
                        crate::network::check_domain(
                            &xml.replace("network='forge-whonix'", "network='forge-standard'"),
                            role,
                            mode
                        )
                        .is_err()
                    );
                }
                assert!(
                    crate::network::check_domain(
                        &xml.replace("</devices>", "<interface type='user'/></devices>"),
                        role,
                        mode
                    )
                    .is_err()
                );
            }
        }
    }

    #[test]
    fn isolated_xml_has_no_nic() {
        let xml = domain_xml(&isolated_spec());
        assert!(!xml.contains("<interface"));
        assert!(!xml.contains("virbr0"));
        assert!(!xml.contains("type='user'"));
        check_role(&xml, Role::Isolated).expect("isolated ok");
        let facts = inspect(&xml);
        assert_eq!(facts.forge_profile.as_deref(), Some("tsurugi"));
        assert_eq!(facts.forge_role.as_deref(), Some("isolated"));
        assert!(xml.contains("<backingStore"));
        assert!(xml.contains("relabel='no'"));
        crate::security::validate_domain(&xml, crate::security::Policy::Selinux).unwrap();
        assert_eq!(facts.disk_files.len(), 2);
        assert!(facts.disk_files[0].ends_with("vms/tsurugi.qcow2"));
        assert!(facts.disk_files[1].ends_with("bases/tsurugi.qcow2"));
    }

    #[test]
    fn isolated_with_default_net_is_error() {
        let mut xml = domain_xml(&isolated_spec());
        xml = xml.replace(
            "</disk>\n",
            "</disk>\n    <interface type='network'><source network='default'/></interface>\n",
        );
        let err = check_role(&xml, Role::Isolated).expect_err("must fail");
        let msg = err.to_string();
        assert!(msg.contains("NAT") || msg.contains("NIC"));
    }

    #[test]
    fn kali_xml_is_osint_no_nic() {
        let spec = DomainSpec {
            name: "kali",
            uuid: "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            profile: "kali",
            role: Role::OsintClearnet,
            overlay: "/var/lib/forge/vms/kali.qcow2",
            base: "/var/lib/forge/bases/kali.qcow2",
            base_digest: "sha256:deadbeef",
            memory_mib: 4096,
            vcpus: 2,
        };
        let xml = domain_xml(&spec);
        assert!(!xml.contains("<interface"));
        assert!(xml.contains("osint-clearnet"));
        check_role(&xml, Role::OsintClearnet).expect("osint ok");
        let with_nat = xml.replace(
            "</disk>\n",
            "</disk>\n    <interface type='network'><source network='default'/></interface>\n",
        );
        assert!(check_role(&with_nat, Role::OsintClearnet).is_err());
    }

    #[test]
    fn whonix_pair_xml_roles() {
        let gw = DomainSpec {
            name: "whonix-gateway",
            uuid: "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            profile: "whonix",
            role: Role::WhonixGw,
            overlay: "/var/lib/forge/vms/whonix-gateway.qcow2",
            base: "/var/lib/forge/bases/whonix-gateway.qcow2",
            base_digest: "sha256:gw",
            memory_mib: 2048,
            vcpus: 2,
        };
        let ws = DomainSpec {
            name: "whonix-workstation",
            uuid: "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
            profile: "whonix",
            role: Role::WhonixWs,
            overlay: "/var/lib/forge/vms/whonix-workstation.qcow2",
            base: "/var/lib/forge/bases/whonix-workstation.qcow2",
            base_digest: "sha256:ws",
            memory_mib: 4096,
            vcpus: 2,
        };
        let gw_xml = domain_xml(&gw);
        let ws_xml = domain_xml(&ws);
        assert!(gw_xml.find("forge-wan").unwrap() < gw_xml.find("forge-whonix").unwrap());
        assert!(ws_xml.contains("forge-whonix"));
        assert!(!gw_xml.contains("default"));
        assert!(!ws_xml.contains("<hostdev"));
        check_role(&gw_xml, Role::WhonixGw).unwrap();
        check_role(&ws_xml, Role::WhonixWs).unwrap();
        let swapped = gw_xml
            .replace("forge-wan", "NET_A")
            .replace("forge-whonix", "forge-wan")
            .replace("NET_A", "forge-whonix");
        assert!(check_role(&swapped, Role::WhonixGw).is_err());
        let with_usb = format!(
            "{gw_xml}{}",
            crate::usb::UsbId::parse("0bda:8153").unwrap().hostdev_xml()
        );
        assert!(check_role(&with_usb, Role::WhonixGw).is_err());
    }

    #[test]
    fn isolated_rejects_usb_hostdev() {
        let mut xml = domain_xml(&isolated_spec());
        xml = xml.replace(
            "</devices>",
            &format!(
                "{}</devices>",
                crate::usb::UsbId::parse("0b95:1790").unwrap().hostdev_xml()
            ),
        );
        let err = check_role(&xml, Role::Isolated).expect_err("usb");
        assert!(err.to_string().contains("USB"));
    }

    #[test]
    fn pci_hostdev_stays_on_the_host() {
        let mut xml = domain_xml(&isolated_spec());
        xml = xml.replace("</devices>", "<hostdev mode='subsystem' type='pci' managed='yes'><source><address domain='0x0000' bus='0x0a' slot='0x00' function='0x0'/></source></hostdev></devices>");
        let err = check_role(&xml, Role::Isolated).expect_err("pci");
        assert!(err.to_string().contains("PCI"));
    }
}
