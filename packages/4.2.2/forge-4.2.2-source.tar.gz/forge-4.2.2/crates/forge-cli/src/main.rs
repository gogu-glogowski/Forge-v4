mod music;

use std::io::{self, Write};
use std::process::ExitCode;

use clap::{Parser, Subcommand};
use forge_core::doctor;
use forge_core::progress::{ProgressEvent, format_bytes};
use forge_core::{APP_NAME, DongleLink, Forge, ForgeError, Profile, format_list, format_status};

#[derive(Parser)]
#[command(
    name = "forge",
    version,
    about = "Forge 4.2.2 — KVM lab with standard or dedicated networking",
    long_about = None,
    arg_required_else_help = true
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Configure Standard NAT (default for new labs) or a Dedicated A/B network
    Setup {
        #[arg(long, value_parser = ["standard", "dedicated"])]
        network: Option<String>,
    },
    /// Download and verify an upstream image into an immutable base
    Pull { profile: String },
    /// Prepare selected bases and default VMs, with optional local background music
    Prepare {
        #[arg(
            long,
            required_unless_present = "profiles",
            conflicts_with = "profiles"
        )]
        all: bool,
        /// Comma-separated selection; Whonix always includes gateway and workstation
        #[arg(long, value_delimiter = ',', num_args = 1, value_parser = ["tsurugi", "kali", "whonix", "sift"])]
        profiles: Vec<String>,
        /// Only download and verify bases; do not configure hooks, networks or VMs
        #[arg(long)]
        images_only: bool,
        /// Local SANS OVA; otherwise unavailable SIFT is explicitly skipped
        #[arg(long)]
        sift_ova: Option<std::path::PathBuf>,
        /// Disable background music
        #[arg(long)]
        no_music: bool,
        /// Directory containing local MP3/OGG/FLAC/WAV/M4A tracks
        #[arg(long)]
        music_dir: Option<std::path::PathBuf>,
    },
    /// Create an overlay VM from a pulled base (role comes from the profile)
    Create {
        profile: String,
        name: Option<String>,
    },
    /// Clone a VM by name (not by file). Whonix: refused
    Clone { vm: String, new_name: String },
    /// Start a VM (refuses if base digest or role XML drifted)
    Start { vm: String },
    /// ACPI shutdown. --force cuts power
    Stop {
        vm: String,
        #[arg(long)]
        force: bool,
    },
    /// Dedicated mode: attach dongle B to a running Kali. The Whonix gateway uses B as its router exit, not as a USB device
    Connect { vm: String },
    /// Dedicated mode: remove dongle B. The VM keeps running
    Disconnect { vm: String },
    /// Running state plus role/network proof
    Status { vm: Option<String> },
    /// One inventory: profiles, base on disk, VM names
    List,
    /// Delete a Forge VM and its overlay. Base stays
    Delete { vm: String },
    /// Diagnostics (not shown in default --help)
    #[command(hide = true)]
    Dev {
        #[command(subcommand)]
        command: DevCommands,
    },
}

#[derive(Subcommand)]
enum DevCommands {
    /// Inspect host distribution, services, security, tools and Forge readiness
    Doctor,
    /// Domain XML vs role
    Xml { vm: String },
    /// create with --dry-run (prints XML, defines nothing)
    Create {
        profile: String,
        name: Option<String>,
        #[arg(long)]
        dry_run: bool,
    },
    /// delete with --dry-run
    Delete {
        vm: String,
        #[arg(long)]
        dry_run: bool,
    },
    /// USB net devices and dongle B pin
    Usb,
    /// Keep cable A as the only host uplink and take USB dongle B off NetworkManager
    Cables,
    /// Install the root libvirt qemu hook. Does not start a VM
    Hook,
}

fn main() -> ExitCode {
    if forge_core::effective_uid() == 0 {
        return match forge_core::root_entry() {
            Ok(()) => ExitCode::SUCCESS,
            Err(error) => {
                eprintln!("{APP_NAME}: {error}");
                ExitCode::from(1)
            }
        };
    }
    let args: Vec<String> = std::env::args().skip(1).collect();
    if let Some(hint) = leftover_hint(&args) {
        eprintln!("{APP_NAME}: {hint}");
        return ExitCode::from(2);
    }
    let cli = Cli::parse();
    match run(cli) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("{APP_NAME}: {error}");
            ExitCode::from(error.exit_code())
        }
    }
}

fn leftover_hint(args: &[String]) -> Option<String> {
    let first = args.first()?.as_str();
    if first == "--help" || first == "-h" || first == "--version" || first == "-V" {
        return None;
    }
    match first {
        "doctor" => Some("diagnostics live under `forge dev doctor`".to_owned()),
        "image" | "profile" | "vm" => {
            Some("v2 command maze is gone. See `forge --help`".to_owned())
        }
        _ => None,
    }
}

fn run(cli: Cli) -> Result<(), ForgeError> {
    if forge_core::effective_uid() == 0 {
        return Err(ForgeError::Host(
            "run as yourself, not `sudo forge` (root PATH misses ~/.local/bin; overlays would be root-owned). pull/create prompt sudo only for /var/lib/forge".to_owned(),
        ));
    }
    match cli.command {
        Commands::Setup { network } => {
            let forge = Forge::open()?;
            let mode = forge.setup_network(network.as_deref().map(str::parse).transpose()?)?;
            println!("Network mode: {}", mode.label());
            println!("Setup complete. Use GNOME Boxes → QEMU System.");
            Ok(())
        }
        Commands::Pull { profile } => {
            let profile: Profile = profile.parse()?;
            let forge = Forge::open()?;
            forge.pull(profile, &cli_progress())?;
            println!("pulled {}", profile.id());
            Ok(())
        }
        Commands::Prepare {
            all,
            profiles,
            sift_ova,
            images_only,
            no_music,
            music_dir,
        } => {
            if sift_ova.as_ref().is_some_and(|path| !path.is_file()) {
                return Err(ForgeError::InvalidInput(
                    "--sift-ova must point to an existing local OVA file".to_owned(),
                ));
            }
            let forge = Forge::open()?;
            let music = music::Session::default();
            let stop = music.stopper();
            ctrlc::set_handler(move || {
                stop();
                std::process::exit(130);
            })
            .map_err(|error| {
                ForgeError::Host(format!("cannot install interruption handler: {error}"))
            })?;
            music.start(&forge.paths.meta, !no_music, music_dir);
            let output = cli_progress();
            let progress = move |event: &ProgressEvent| {
                music.poll();
                output(event);
            };
            let report = if images_only {
                let selected = if all {
                    vec![
                        Profile::Tsurugi,
                        Profile::Kali,
                        Profile::Whonix,
                        Profile::Sift,
                    ]
                } else {
                    profiles
                        .iter()
                        .map(|p| p.parse())
                        .collect::<Result<Vec<Profile>, _>>()?
                };
                forge.download_selected(&selected, sift_ova.as_deref(), &progress)?
            } else if all {
                forge.prepare_all(sift_ova.as_deref(), &progress)?
            } else {
                let profiles = profiles
                    .iter()
                    .map(|p| p.parse())
                    .collect::<Result<Vec<Profile>, _>>()?;
                forge.prepare_selected(&profiles, sift_ova.as_deref(), &progress)?
            };
            drop(progress);
            println!(
                "Prepared: {}",
                report
                    .prepared
                    .iter()
                    .map(|p| p.id())
                    .collect::<Vec<_>>()
                    .join(", ")
            );
            for skipped in report.skipped {
                println!("Skipped: {skipped}");
            }
            println!("VMs are powered off. Open GNOME Boxes → QEMU System when ready.");
            Ok(())
        }
        Commands::Create { profile, name } => {
            let profile: Profile = profile.parse()?;
            let forge = Forge::open()?;
            let created = forge.create(profile, name.as_deref(), false, &cli_progress())?;
            for vm in &created {
                println!("created {}  uuid={}", vm.name, vm.uuid);
            }
            if profile == Profile::Whonix {
                println!(
                    "Start the gateway first (`forge start whonix-gateway`), then the workstation. The workstation only reaches the gateway."
                );
            } else {
                println!(
                    "Open it in GNOME Boxes. If the list is empty, quit Boxes fully and reopen — Forge points it at qemu:///system."
                );
            }
            Ok(())
        }
        Commands::Clone { vm, new_name } => {
            let forge = Forge::open()?;
            let created = forge.clone_vm(&vm, &new_name, &cli_progress())?;
            println!("cloned {vm} -> {}", created.name);
            Ok(())
        }
        Commands::Start { vm } => {
            let forge = Forge::open()?;
            forge.start(&vm, &cli_progress())?;
            println!("started {vm}");
            println!("Daily display: GNOME Boxes. Spare: virt-manager.");
            Ok(())
        }
        Commands::Stop { vm, force } => {
            let forge = Forge::open()?;
            forge.stop(&vm, force)?;
            if force {
                println!("destroyed {vm}");
            } else {
                println!("shutdown {vm}");
            }
            Ok(())
        }
        Commands::Connect { vm } => {
            let forge = Forge::open()?;
            match forge.connect_dongle(&vm, &cli_progress())? {
                DongleLink::Connected(id) => println!("connected dongle B {id} to {vm}"),
                DongleLink::Already(id) => println!("dongle B {id} is already in {vm}"),
                DongleLink::Disconnected | DongleLink::Absent => {}
            }
            Ok(())
        }
        Commands::Disconnect { vm } => {
            let forge = Forge::open()?;
            match forge.disconnect_dongle(&vm)? {
                DongleLink::Disconnected => {
                    println!("disconnected dongle B from {vm}; the VM stays up");
                }
                DongleLink::Absent => println!("dongle B is not in {vm}"),
                DongleLink::Connected(_) | DongleLink::Already(_) => {}
            }
            Ok(())
        }
        Commands::Status { vm } => {
            let forge = Forge::open()?;
            let rows = forge.status(vm.as_deref())?;
            println!("Network mode: {}", forge.network_mode()?.label());
            print!("{}", format_status(&rows));
            if rows.iter().any(|row| row.role_ok.is_err()) {
                return Err(ForgeError::Role("role/network proof failed".to_owned()));
            }
            Ok(())
        }
        Commands::List => {
            let forge = Forge::open()?;
            print!("{}", format_list(&forge.list()?));
            Ok(())
        }
        Commands::Delete { vm } => {
            let forge = Forge::open()?;
            let plan = forge.delete(&vm, false)?;
            println!("{plan}");
            Ok(())
        }
        Commands::Dev { command } => run_dev(command),
    }
}

fn run_dev(command: DevCommands) -> Result<(), ForgeError> {
    match command {
        DevCommands::Doctor => {
            let report = doctor::run()?;
            print!("{}", doctor::format_report(&report));
            if report.ok() {
                Ok(())
            } else {
                Err(ForgeError::Host("doctor found failures".to_owned()))
            }
        }
        DevCommands::Xml { vm } => {
            let forge = Forge::open()?;
            print!("{}", forge.dump_xml(&vm)?);
            Ok(())
        }
        DevCommands::Create {
            profile,
            name,
            dry_run,
        } => {
            if !dry_run {
                return Err(ForgeError::InvalidInput(
                    "forge dev create requires --dry-run (live create is `forge create`)"
                        .to_owned(),
                ));
            }
            let profile: Profile = profile.parse()?;
            let forge = Forge::open()?;
            let created = forge.create(profile, name.as_deref(), true, &cli_progress())?;
            for vm in &created {
                print!("{}", vm.xml);
            }
            Ok(())
        }
        DevCommands::Delete { vm, dry_run } => {
            if !dry_run {
                return Err(ForgeError::InvalidInput(
                    "forge dev delete requires --dry-run (live delete is `forge delete`)"
                        .to_owned(),
                ));
            }
            let forge = Forge::open()?;
            println!("{}", forge.delete(&vm, true)?);
            Ok(())
        }
        DevCommands::Usb => {
            let forge = Forge::open_paths(forge_core::ForgePaths::discover())?;
            print!("{}", forge.usb_report());
            Ok(())
        }
        DevCommands::Cables => {
            let forge = Forge::open_paths(forge_core::ForgePaths::discover())?;
            print!("{}", forge.enforce_cables()?);
            Ok(())
        }
        DevCommands::Hook => {
            let forge = Forge::open_paths(forge_core::ForgePaths::discover())?;
            forge.install_hook()?;
            println!("qemu hook installed");
            Ok(())
        }
    }
}

fn cli_progress() -> impl Fn(&ProgressEvent) + Send + Sync {
    |event| match event {
        ProgressEvent::Message(text) => eprintln!("{text}"),
        ProgressEvent::Bytes { done, total, .. } => {
            if let Some(total) = total {
                eprint!(
                    "\r  {} / {} ({:.0}%)",
                    format_bytes(*done),
                    format_bytes(*total),
                    (*done as f64 / *total as f64) * 100.0
                );
            } else {
                eprint!("\r  {}", format_bytes(*done));
            }
            let _ = io::stderr().flush();
            if total.is_some_and(|total| *done >= total) {
                eprintln!();
            }
        }
    }
}
